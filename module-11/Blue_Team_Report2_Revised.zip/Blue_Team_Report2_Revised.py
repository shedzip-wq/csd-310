# Blue Team
# Sheridan Dela Cruz
# Garvin Stewart
# Megan Mosier
# Garret Woods
# May 22, 2026
# Milestone 5

import mysql.connector

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="outdoor_adventure1"
)

cursor = db.cursor()

print("\n--- Trips by Location Report ---")

query = """
SELECT 
    l.Destination,
    COUNT(t.TripID) AS NumberOfTrips
FROM location l
LEFT JOIN trip t ON l.LocationID = t.LocationID
GROUP BY l.Destination;
"""

cursor.execute(query)

for row in cursor.fetchall():
    print(f"{row[0]}: {row[1]} trips")

cursor.close()
db.close()
