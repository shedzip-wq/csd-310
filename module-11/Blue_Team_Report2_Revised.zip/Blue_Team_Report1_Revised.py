# Blue Team
# Sheridan Dela Cruz
# Garvin Stewart
# Megan Mosier
# Garret Woods
# May 22, 2026
# Milestone 5

import mysql.connector

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="outdoor_adventure1"
)

cursor = db.cursor()

print("\n--- Equipment Sales vs Rentals Report ---")

cursor.execute("SELECT COUNT(*) FROM equipmentrental;")
total_rentals = cursor.fetchone()[0]
print(f"Total Equipment Rentals: {total_rentals}")

cursor.execute("SELECT COUNT(*) FROM equipmentsale;")
total_sales = cursor.fetchone()[0]
print(f"Total Equipment Sales: {total_sales}")

cursor.execute("SELECT DISTINCT CustomerID FROM equipmentrental;")
rental_customers = set(row[0] for row in cursor.fetchall())

cursor.execute("SELECT DISTINCT CustomerID FROM equipmentsale;")
sale_customers = set(row[0] for row in cursor.fetchall())

both = rental_customers.intersection(sale_customers)

print(f"Customers who rented: {len(rental_customers)}")
print(f"Customers who bought: {len(sale_customers)}")
print(f"Customers who both rented and bought: {len(both)}")

cursor.close()
db.close()
