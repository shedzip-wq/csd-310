Blue Team
Sheridan Dela Cruz, Garvin Stewart, Megan Mosier, Garrett Woods


USE outdoor_adventure1;
SHOW TABLES;
INSERT INTO Customer (CustomerID, Name, ContactInfo, RunningBalance) VALUES
(1, 'Alice Tran', 'atran@email.com', 250.00),
(2, 'Marcus Webb', 'mwebb@email.com', 500.00),
(3, 'Sandra Okafor', 'sokafor@email.com', 175.00),
(4, 'Derek Lim', 'dlim@email.com', 320.00),
(5, 'Priya Kapoor', 'pkapoor@email.com', 0.00),
(6, 'Ben Nakamura', 'bnakamura@email.com', 100.00);

INSERT INTO Equipment (EquipmentID, EquipmentType, PurchaseDate, ConditionStatus, QuantityAvailable) VALUES
(1, 'Kayak', '2023-03-15', 'Good', 8),
(2, 'Mountain Bike', '2023-05-20', 'Excellent', 10),
(3, 'Climbing Harness', '2022-08-10', 'Fair', 15),
(4, 'Canoe', '2023-01-25', 'Good', 6),
(5, 'Snowshoes', '2022-11-30', 'Excellent', 12),
(6, 'Tent (4-person)', '2024-01-10', 'Excellent', 20);

INSERT INTO EquipmentRental (CustomerID, EquipmentID, RentalStartDate, RentalEndDate, ConditionOnReturn) VALUES
(1, 1, '2025-03-01', '2025-03-15', 'Good'),
(2, 2, '2025-04-10', '2025-04-24', 'Excellent'),
(3, 3, '2025-05-20', '2025-06-03', 'Fair'),
(4, 4, '2025-07-01', '2025-07-14', 'Good'),
(5, 5, '2025-09-05', '2025-09-19', NULL),
(6, 6, '2025-10-10', '2025-10-24', NULL);

SELECT * FROM EquipmentRental;

INSERT INTO equipmentsale (CustomerID, EquipmentID, SaleDate, SalePrice) VALUES
(1, 2, '2025-03-20', 450.00),
(2, 3, '2025-04-15', 120.00),
(3, 1, '2025-05-25', 600.00),
(4, 5, '2025-07-10', 80.00),
(5, 4, '2025-09-10', 300.00),
(6, 6, '2025-10-15', 200.00);
SELECT * FROM equipmentsale;
USE outdoor_adventure1;
-- LOCATION (6 records)
INSERT INTO Location (RegionName, Destination) VALUES
('Africa',          'Cairo, Egypt'),
('Asia',            'Beijing, China'),
('Southern Europe', 'Venice, Italy'),
('Africa',          'Dodoma, Tanzania'),
('Asia',            'Tokyo, Japan'),
('Southern Europe', 'Madrid, Spain');
SELECT * FROM location;

-- TRIP (6 records)
INSERT INTO Trip (LocationID, TripName, StartDate, EndDate, MaxParticipants) VALUES
(1, 'Pyramids & Nile Explorer',   '2025-03-01', '2025-03-15', 12),
(2, 'Great Wall & Beijing Stroll','2025-04-10', '2025-04-24', 10),
(3, 'Venetian Canals Journey',    '2025-05-20', '2025-06-03', 14),
(4, 'Serengeti Safari',           '2025-07-01', '2025-07-14', 8),
(5, 'Tokyo Cultural Immersion',   '2025-09-05', '2025-09-19', 15),
(6, 'Iberian Adventure',          '2025-10-10', '2025-10-24', 12);
SELECT * FROM trip;

-- BOOKING (6 records)
INSERT INTO Booking (TripID, CustomerID, BookingDate) VALUES
(1, 1, '2024-11-01'),
(2, 2, '2024-11-15'),
(3, 3, '2024-12-01'),
(4, 4, '2024-12-10'),
(5, 5, '2025-01-05'),
(6, 6, '2025-01-20');
SELECT * FROM booking;
DESCRIBE location;

DESCRIBE billing;
SELECT 
    c.CustomerID,
    c.Name,
    SUM(b.AmountCharged) AS TotalBilling
FROM customer c
LEFT JOIN billing b ON c.CustomerID = b.CustomerID
GROUP BY c.CustomerID, c.Name;
INSERT INTO Billing (CustomerID, BillingPeriod, BillingMethod, AmountCharged) VALUES
(1, 'March 2025',   'Credit Card', 1200.00),
(2, 'April 2025',   'Credit Card', 1500.00),
(3, 'May 2025',     'Bank Transfer', 950.00),
(4, 'July 2025',    'Credit Card', 1100.00),
(5, 'September 2025','Check',      1350.00),
(6, 'October 2025', 'Credit Card', 1250.00);

SELECT 
    EquipmentID,
    EquipmentType,
    PurchaseDate,
    ConditionStatus,
    QuantityAvailable
FROM equipment
WHERE PurchaseDate <= DATE_SUB(CURDATE(), INTERVAL 5 YEAR);









